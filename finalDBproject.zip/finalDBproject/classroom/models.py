from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils.html import escape, mark_safe

# Create your models here.
class User(AbstractUser):
    is_student = models.BooleanField(default=False)
    is_teacher = models.BooleanField(default=False)
    is_admin = models.BooleanField(default=False)
   
class Person(models.Model):
    ssn = models.IntegerField(primary_key=True)
    Fname = models.CharField(max_length=20)
    Lname = models.CharField(max_length=20)
    Minit = models.CharField(max_length=20)
    dob = models.DateField()
    sex = models.CharField(max_length=20)
    Phone_no = models.IntegerField()
    Street = models.CharField(max_length=50)
    City = models.CharField(max_length=50)
    State = models.CharField(max_length=50)
    Zip =  models.CharField(max_length=50)
    username = models.ForeignKey('User', to_field='username', on_delete=models.CASCADE)

class Faculty(models.Model):
    fssn = models.ForeignKey('Person',on_delete=models.CASCADE, primary_key=True)
    salary = models.IntegerField()
    fphone = models.IntegerField()
    foffice = models.IntegerField()
    rank = models.CharField(max_length=10)
    join_date = models.DateField()
    inst_ssn = models.ForeignKey('Instructor',on_delete=models.CASCADE)

class Course(models.Model):
    cno=models.IntegerField(primary_key=True)
    cdesc=models.CharField(max_length=1000)
    cname=models.CharField(max_length=100)
    Ch=models.IntegerField()
    dname=models.ForeignKey('Department',on_delete=models.CASCADE)



class Gradstd(models.Model):
    gssn=models.ForeignKey('Student',on_delete=models.CASCADE,primary_key=True)
    advssn=models.ForeignKey('Faculty',on_delete=models.CASCADE,default='')
    inst_ssn = models.ForeignKey('Instructor',on_delete=models.CASCADE)

class Committee(models.Model):
    facssn=models.ForeignKey('Faculty',on_delete=models.CASCADE, default='')
    stdssn=models.ForeignKey('Gradstd',on_delete=models.CASCADE)
    class Meta:
        unique_together = (('facssn', 'stdssn'),)



class Gradstdegrees(models.Model):
    gdssn=models.ForeignKey('Gradstd',on_delete=models.CASCADE)
    degree= models.CharField(max_length=10)
    colg= models.CharField(max_length=20)
    year=models.CharField(max_length=10)
    class Meta:
        unique_together = (('gdssn', 'degree', 'colg', 'year'),)


class Fee(models.Model):
    Amount= models.IntegerField()
    feetype= models.CharField(max_length=50,default='')
    Stussn= models.ForeignKey('Student',on_delete=models.CASCADE)
    Feeid= models.IntegerField(primary_key=True)

class Semfee(models.Model):
    semester=models.CharField(max_length=50)
    fid=models.ForeignKey('Fee',on_delete=models.CASCADE)
    paiddate= models.DateField()
    duedate=models.DateField()

class Section(models.Model):
    secno=models.IntegerField(primary_key=True)
    sem=models.CharField(max_length=50)
    courseno=models.ForeignKey('Course',on_delete=models.CASCADE)
    inssn=models.ForeignKey('Instructor',on_delete=models.CASCADE)

class Cursection(models.Model):
    csecno=models.ForeignKey('Section',on_delete=models.CASCADE,primary_key=True)

class Department(models.Model):
    dname=models.CharField(max_length=50,primary_key=True)
    dphone=models.IntegerField()
    doffice=models.IntegerField()
    coname=models.ForeignKey('College',on_delete=models.CASCADE)

class College(models.Model):
    colname=models.CharField(max_length=50,primary_key=True)
    dean= models.CharField(max_length=30)
    office= models.IntegerField()

class Support(models.Model):
    grantno=models.IntegerField()
    instssn=models.ForeignKey('Instructor',on_delete=models.CASCADE)
    start= models.DateField()
    end= models.DateField()
    time=models.CharField(max_length=15)
    class Meta:
        unique_together = (('grantno','instssn'),)

class Regsub(models.Model):
    secno=models.ForeignKey('Cursection',on_delete=models.CASCADE)
    stussn=models.ForeignKey('Student',on_delete=models.CASCADE)
    class Meta:
        unique_together = (('secno','stussn'),)

class Transcript(models.Model):
    grade=models.CharField(max_length=2)
    scno=models.ForeignKey('Section',on_delete=models.CASCADE)
    stdssn=models.ForeignKey('Student',on_delete=models.CASCADE)
    class Meta:
        unique_together = (('scno','stdssn'),)

class Enrolls(models.Model):
    stdssn=models.ForeignKey('Student',on_delete=models.CASCADE)
    couno=models.ForeignKey('Course',on_delete=models.CASCADE)
    attendance=models.IntegerField()
    class Meta:
        unique_together = (('couno','stdssn'),)

  

    #there are many django fields for many attributes for making a database!

class Student(models.Model):
    Studentssn = models.ForeignKey('Person',on_delete=models.CASCADE, primary_key=True)
    Dept = models.ForeignKey('Department',on_delete=models.CASCADE)
    Class = models.IntegerField()

class Grant(models.Model):
    gno= models.IntegerField(primary_key=True)
    title = models.CharField(max_length=100)
    agency= models.CharField(max_length=50)
    startdate=models.DateField()
    facssn= models.ForeignKey('Faculty',on_delete=models.CASCADE, default='')

class Instructor(models.Model):
    issn=models.IntegerField(primary_key=True)




    



    

