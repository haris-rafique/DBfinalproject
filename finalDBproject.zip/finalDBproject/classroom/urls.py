from django.urls import include, path, re_path

from .views import classroom

urlpatterns = [
    path('',classroom.home,name='home'),
    re_path(r'^addcourse/(?P<pk>\d+)$',classroom.addcourse,name='addcourse'),
    re_path(r'^removecourse/(?P<pk>\d+)$',classroom.removecourse,name='removecourse'),
    path('listofcourses',classroom.fullcourses,name='listofcourses'),
    #student functions
    re_path(r'^student_profile/(?P<pk>\d+)$',classroom.student_profile,name='student_profile'),
    re_path(r'^currentcourses/(?P<pk>\d+)$', classroom.currentcourses, name='currentcourses'),
    re_path(r'^attendance/(?P<pk>\d+)$',classroom.attendance,name='attendance'),
    re_path(r'^dmc/(?P<pk>\d+)$',classroom.dmc,name='dmc'),
    re_path(r'^dues/(?P<pk>\d+)$',classroom.dues,name='dues'),
    #instructor functions
    re_path(r'^instructor_profile/(?P<pk>\d+)$', classroom.instructor_profile, name='instructor_profile'),
    
    re_path(r'^allattendance/(?P<pk>\d+)$', classroom.allattendance, name='allattendance'),
    re_path(r'^courses_taught/(?P<pk>\d+)$', classroom.courses_taught, name='courses_taught'),
    #admin functions
    re_path(r'^allstudents/(?P<pk>\d+)$', classroom.allstudents, name='allstudents'),
    re_path(r'^allinstructors/(?P<pk>\d+)$', classroom.allinstructors, name='allinstructors'),
    re_path(r'^allcourses/(?P<pk>\d+)$', classroom.allcourses, name='allcourses'),
     
]
