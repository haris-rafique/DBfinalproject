from django.shortcuts import redirect, render
from django.views.generic import TemplateView
from django.template import RequestContext
from django import forms
from django.db import connection
from ..models import User, Student, Instructor,Course, Person
from django.contrib.auth import login
from django.views.generic import CreateView, ListView, UpdateView

from ..forms import  TeacherSignUpForm, AdminSignUpForm, StudentSignUpForm



class TeacherSignUpView(CreateView):
    model = User
    form_class = TeacherSignUpForm
    template_name = 'registration/signup_form.html'

    def get_context_data(self, **kwargs):
        kwargs['user_type'] = 'teacher'
        return super().get_context_data(**kwargs)

    def form_valid(self, form):
        user = form.save()
        login(self.request, user)
        
        return redirect('home')

class AdminSignUpView(CreateView):
    model = User
    form_class = AdminSignUpForm
    template_name = 'registration/signup_form.html'

    def get_context_data(self, **kwargs):
        kwargs['user_type'] = 'admin'
        return super().get_context_data(**kwargs)

    def form_valid(self, form):
        user = form.save()
        login(self.request, user)
        return redirect('home')


class SignUpView(TemplateView):
    template_name = 'registration/signup.html'





class StudentSignUpView(CreateView):
    model = User
    form_class = StudentSignUpForm
    template_name = 'registration/signup_form.html'
    
    def get_context_data(self, **kwargs):
        kwargs['user_type'] = 'student'
        return super().get_context_data(**kwargs)
    

    def form_valid(self, form):
        user = form.save()
        login(self.request, user)
        
        return redirect('home')

def student_profile(request, pk=None):
    user1=request.user.username
    if pk:
        user=User.objects.filter(pk=pk)
    
    with connection.cursor() as cursor:
        cursor.execute(" select distinct Fname, Lname, ssn, dob, class, dname, colname \
                        from classroom_user, classroom_person, classroom_college, classroom_department, classroom_student \
                        where classroom_person.username_id = %s and classroom_person.ssn = classroom_student.Studentssn_id and classroom_student.Dept_id = classroom_department.dname \
                        and classroom_department.coname_id = classroom_college.colname; \
                        ",[user1])
        rows = cursor.fetchall()
        headers = ("First Name", "Surname", "SSN", "Date of Birth", 'Class', 'Department', 'Campus')
    return render(request, "classroom/studentprofile.html", {'headers':headers, 'rows':rows}) 

def currentcourses(request,pk=None):
    user1=request.user.username
    if pk:
        user=User.objects.filter(pk=pk)
        #user=User.objects.all(pk=pk)
    
        with connection.cursor() as cursor:
            cursor.execute("select sem, cname, cdesc, CH, Fname, Lname from (select sem, cname, cdesc, CH, inssn_id from classroom_person, classroom_student, classroom_regsub, classroom_cursection, classroom_section, classroom_course \
                            where classroom_person.username_id= %s and classroom_person.ssn = classroom_student.Studentssn_id and classroom_student.Studentssn_id = classroom_regsub.stussn_id and classroom_regsub.secno_id = classroom_cursection.csecno_id and classroom_cursection.csecno_id = classroom_section.secno and classroom_section.courseno_id = classroom_course.cno) as SEM, classroom_faculty, classroom_person where SEM.inssn_id = classroom_faculty.fssn_id and classroom_faculty.fssn_id = classroom_person.ssn;\
                            ",[user1])
            rows = cursor.fetchall()
            headers = ("Semester", "Name of course", "Description", "Credit Hours","First Name", 'Surname')
        
        return render(request, "classroom/courses.html", {'headers':headers, 'rows':rows})




def addcourse(request,pk=None):
    user1=request.user.username
    
    if pk:
        user=User.objects.filter(pk=pk)
    
    with connection.cursor() as cursor:
        cursor.execute("select ssn from classroom_person where classroom_person.username_id=%s",[user1])
        value=cursor.fetchone()
        cursor.execute("select secno from classroom_section where secno not in (select secno_id from classroom_regsub where stussn_id=%s) order by secno asc;",[value])
        secno=cursor.fetchone()
        cursor.execute("insert into classroom_regsub (secno_id,stussn_id) values (%s,%s)",[secno,value])
        cursor.execute("select sem, cname, cdesc, CH, Fname, Lname from (select sem, cname, cdesc, CH, inssn_id from classroom_person, classroom_student, classroom_regsub, classroom_cursection, classroom_section, classroom_course \
                        where classroom_person.username_id= %s and classroom_person.ssn = classroom_student.Studentssn_id and classroom_student.Studentssn_id = classroom_regsub.stussn_id and classroom_regsub.secno_id = classroom_cursection.csecno_id and classroom_cursection.csecno_id = classroom_section.secno and classroom_section.courseno_id = classroom_course.cno) as SEM, classroom_faculty, classroom_person where SEM.inssn_id = classroom_faculty.fssn_id and classroom_faculty.fssn_id = classroom_person.ssn;\
                        ",[user1])
        rows = cursor.fetchall()
        headers = ("Semester", "Name of course", "Description", "Credit Hours","First Name", 'Surname')
    


    return render(request,"classroom/courses.html",{'headers':headers, 'rows':rows})


def removecourse(request,pk=None):
    user1=request.user.username
     
    if pk:
        user=User.objects.filter(pk=pk)
    with connection.cursor() as cursor:
        cursor.execute("select ssn from classroom_person where classroom_person.username_id=%s",[user1])
        value=cursor.fetchone()
        cursor.execute("select secno from classroom_section where secno in (select secno_id from classroom_regsub where stussn_id=%s )",[value])
        secno=cursor.fetchone()
        cursor.execute("delete from classroom_regsub where secno_id = %s and stussn_id = %s",[secno,value])
        cursor.execute("select sem, cname, cdesc, CH, Fname, Lname from (select sem, cname, cdesc, CH, inssn_id from classroom_person, classroom_student, classroom_regsub, classroom_cursection, classroom_section, classroom_course \
                        where classroom_person.username_id= %s and classroom_person.ssn = classroom_student.Studentssn_id and classroom_student.Studentssn_id = classroom_regsub.stussn_id and classroom_regsub.secno_id = classroom_cursection.csecno_id and classroom_cursection.csecno_id = classroom_section.secno and classroom_section.courseno_id = classroom_course.cno) as SEM, classroom_faculty, classroom_person where SEM.inssn_id = classroom_faculty.fssn_id and classroom_faculty.fssn_id = classroom_person.ssn;\
                        ",[user1])
        rows = cursor.fetchall()
        headers = ("Semester", "Name of course", "Description", "Credit Hours","First Name", 'Surname')
    
    return render(request,"classroom/courses.html",{'headers':headers, 'rows':rows})



def fullcourses(request):
    with connection.cursor() as cursor:
        cursor.execute("select cdesc,cname,Ch,dname_id from classroom_course;")
        rows=cursor.fetchall()
        headers= ("Course Code", "Name of course", "Credit Hours", "Department Name")
    

    return render(request,"classroom/fullcourses.html",{'headers':headers, 'rows':rows})


def attendance(request, pk=None):
    user1=request.user.username
   
    if pk:
        user=User.objects.filter(pk=pk)
    
    with connection.cursor() as cursor:
        cursor.execute(" select cname, cdesc, CH, attendance, Fname, Lname \
                            from (select cname, cdesc, CH, attendance, inssn_id \
                            from classroom_person, classroom_student, classroom_enrolls, classroom_course, classroom_section \
                            where classroom_person.username_id = %s and classroom_person.ssn = classroom_student.Studentssn_id and classroom_student.Studentssn_id = classroom_enrolls.stdssn_id and classroom_enrolls.couno_id = classroom_course.cno and classroom_course.cno = classroom_section.courseno_id) as sem2, classroom_faculty, classroom_person \
                            where sem2.inssn_id = classroom_faculty.fssn_id and classroom_faculty.fssn_id = classroom_person.ssn; \
                        ",[user1])
        rows = cursor.fetchall()
        headers = ("Name of course", "Description", "Credit Hours","Attendance", "First Name", "Last Name")
    return render(request, "classroom/attendance.html", {'headers':headers, 'rows':rows}) 

def dmc(request,pk=None):
    user1=request.user.username
    
    if pk:
        user=User.objects.filter(pk=pk)
    with connection.cursor() as cursor:
        cursor.execute("select sem, cname, cdesc, CH, grade, Fname, Lname \
                        from (select sem, cname, cdesc, CH, grade, inssn_id \
                        from classroom_person, classroom_student, classroom_transcript, classroom_section, classroom_course \
                        where classroom_person.username_id = %s and classroom_person.ssn = classroom_student.Studentssn_id and classroom_student.Studentssn_id = classroom_transcript.stdssn_id and classroom_transcript.scno_id = classroom_section.secno and classroom_section.courseno_id = classroom_course.cno) as sem1, classroom_faculty, classroom_person \
                        where sem1.inssn_id = classroom_faculty.fssn_id and classroom_faculty.fssn_id = classroom_person.ssn;\
                     ",[user1])
        rows = cursor.fetchall()
        headers = ("Semester", "Name of Course" ,"Description" ,"Credit Hours", "Grade", "First Name", 'Surname')
    return render(request, "classroom/dmc.html", {'headers':headers, 'rows':rows}) 

def dues(request,pk=None):
    user1=request.user.username
    if pk:
        user=User.objects.filter(pk=pk)
    with connection.cursor() as cursor:
        cursor.execute(" select feetype, amount, paiddate, duedate \
                        from classroom_person, classroom_student, classroom_fee, classroom_semfee \
                        where classroom_person.username_id = %s and classroom_person.ssn = classroom_student.Studentssn_id \
                            and classroom_student.Studentssn_id = classroom_fee.Stussn_id and classroom_fee.Feeid = classroom_semfee.fid_id; \
        ",[user1])
        rows = cursor.fetchall()
        headers = ("Type of Fee", "Amount" ,"Date of payment", "Last Date")

    with connection.cursor() as cursor:
        cursor.execute(" select feetype, amount \
                        from classroom_person, classroom_student, classroom_fee\
                        where classroom_person.username_id = %s and classroom_person.ssn = classroom_student.Studentssn_id \
                            and feetype != 'Semester Fee' and classroom_student.Studentssn_id = classroom_fee.Stussn_id; \
        ",[user1])
        rows1 = cursor.fetchall()
        headers1 = ("Type of Fee", "Amount")
    return render(request, "classroom/dues.html", {'headers1':headers1, 'rows1':rows1, 'headers':headers, 'rows':rows} ) 



def home(request):
    return render(request, 'index.html')


def instructor_profile (request, pk=None):
    user1=request.user.username
    if pk:
        user=User.objects.filter(pk=pk)
    with connection.cursor() as cursor:
        cursor.execute(" select distinct Fname, Lname, ssn, dob, classroom_faculty.rank, salary, dname, colname \
                        from classroom_person, classroom_faculty, classroom_instructor, classroom_section, classroom_course, classroom_department, classroom_college  \
                        where classroom_person.username_id = %s and classroom_person.ssn = classroom_faculty.fssn_id and classroom_faculty.fssn_id = classroom_instructor.issn and classroom_instructor.issn = classroom_section.inssn_id and classroom_section.courseno_id = classroom_course.cno and classroom_course.dname_id = classroom_department.dname and classroom_department.coname_id = classroom_college.colname; \
        ",[user1])
        rows = cursor.fetchall()
        headers = ("First Name", "Last Name" ,"ID", "Date of Birth", "Occupation", "Salary","Department Name","Name of College" )
    return render(request, "classroom/instructorprofile.html", { 'headers':headers, 'rows':rows} ) 

def courses_taught (request,pk=None):
    user1=request.user.username
    if pk:
        user=User.objects.filter(pk=pk)
    with connection.cursor() as cursor:
        cursor.execute(" select distinct sem, cname, cdesc \
                        from classroom_instructor, classroom_section, classroom_course, classroom_person \
                        where classroom_instructor.issn = classroom_section.inssn_id and classroom_person.username_id = %s and classroom_section.courseno_id = classroom_course.cno; \
        ",[user1])
        rows = cursor.fetchall()
        headers = ("Semester", "Course Name" ,"Course Details")
    return render(request, "classroom/coursestaught.html", { 'headers':headers, 'rows':rows} ) 

def allattendance (request, pk=None):
    user1=request.user.username
    if pk:
        user=User.objects.filter(pk=pk)
    with connection.cursor() as cursor:
        cursor.execute("select distinct cname, cdesc, Fname, Lname, attendance \
                        from classroom_instructor, classroom_section, classroom_course, classroom_enrolls, classroom_student, classroom_person \
                        where classroom_instructor.issn = classroom_section.inssn_id and classroom_section.courseno_id = classroom_course.cno and classroom_course.cno = classroom_enrolls.couno_id and classroom_enrolls.stdssn_id = classroom_student.Studentssn_id and classroom_student.Studentssn_id = classroom_person.ssn \
                        order by cname,Fname; \
        ")
        rows = cursor.fetchall()
        headers = ("Course Name", "Detail of Course" ,"First Name", "Last Name", "Attendance" )
    return render(request, "classroom/allattendance.html", { 'headers':headers, 'rows':rows} ) 


def allstudents(request, pk=None):
    if pk:
        user=User.objects.filter(pk=pk)
    
    with connection.cursor() as cursor:
        cursor.execute("select Fname, Lname, ssn, dob, class, dname, colname \
                        from classroom_person, classroom_college, classroom_department, classroom_student \
                        where classroom_person.ssn = classroom_student.Studentssn_id and classroom_student.Dept_id = classroom_department.dname and classroom_department.coname_id = classroom_college.colname;")
        rows=cursor.fetchall()
        headers=("First Name","Last Name","ID","Date of birth","Section","Department Name","College Name")
    return render(request, "classroom/allstudents.html", {'headers':headers, 'rows':rows})

def allinstructors(request,pk=None):
    if pk:
        user=User.objects.filter(pk=pk)
    with connection.cursor() as cursor:
        cursor.execute("select distinct Fname, Lname, ssn, dob, classroom_faculty.rank, salary, dname, colname \
                        from classroom_person, classroom_faculty, classroom_instructor, classroom_section, classroom_course, classroom_department, classroom_college \
                        where classroom_person.ssn = classroom_faculty.fssn_id and classroom_faculty.fssn_id = classroom_instructor.issn\
                        and classroom_instructor.issn = classroom_section.inssn_id and classroom_section.courseno_id = classroom_course.cno \
                            and classroom_course.dname_id = classroom_department.dname and classroom_department.coname_id = classroom_college.colname;")
        rows=cursor.fetchall()
        headers=("First Name","Last Name","ID","Date of birth","Occupation","Salary","Department Name","College Name")
    return render(request, "classroom/allinstructors.html", {'headers':headers, 'rows':rows})

def allcourses(request,pk=None):
    if pk:
        user=User.objects.filter(pk=pk)
    with connection.cursor() as cursor:
        cursor.execute("select distinct sem, cname, cdesc, dname \
                        from classroom_section, classroom_course, classroom_department\
                        where classroom_section.courseno_id = classroom_course.cno and classroom_course.dname_id = classroom_department.dname;")
        rows=cursor.fetchall()
        headers=("Semester","Course Name","Detail of Course","Department Name")
    return render(request, "classroom/allcourses.html", {'headers':headers, 'rows':rows})


